#include <iostream>
#include <thread>
#include <mutex>
#include <queue>
#include <semaphore.h>
using namespace std;

queue<int> buffer;
const int BUFFER_SIZE = 5;

mutex m;
sem_t emptySlots;   // counts free spaces
sem_t filledSlots;  // counts items available

void producer() {
    for(int item = 1; item <= 10; item++) {

        sem_wait(&emptySlots); // wait if buffer is full

        m.lock();
        buffer.push(item);
        cout << "Produced: " << item << endl;
        m.unlock();

        sem_post(&filledSlots); // signal item added
    }
}

void consumer() {
    for(int i = 1; i <= 10; i++) {
        
        sem_wait(&filledSlots); // wait if buffer is empty

        m.lock();
        int item = buffer.front();
        buffer.pop();
        cout << "  Consumed: " << item << endl;
        m.unlock();

        sem_post(&emptySlots); // s ignal space freed
    }
}

int main() {
    sem_init(&emptySlots, 0, BUFFER_SIZE); // start with 5 empty slots
    sem_init(&filledSlots, 0, 0);          // start with 0 items

    thread t1(producer);
    thread t2(consumer);

    t1.join();
    t2.join();

    sem_destroy(&emptySlots);
    sem_destroy(&filledSlots);

    cout << "\nDone!" << endl;
}

// g++ pc_sem.cpp -pthread -o pc_sem
// ./pc_sem